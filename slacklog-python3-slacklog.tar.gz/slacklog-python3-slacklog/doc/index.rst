.. slacklog documentation master file, created by
   sphinx-quickstart on Thu Mar 17 14:43:56 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to slacklog's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Introduction <README>
   CHANGES
   cmd
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

